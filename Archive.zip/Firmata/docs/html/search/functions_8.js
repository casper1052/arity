var searchData=
[
  ['queryfirmwareversion_66',['queryFirmwareVersion',['../classfirmata_1_1_firmata_marshaller.html#af954bcf09b77458b3c4f032897d14697',1,'firmata::FirmataMarshaller']]],
  ['queryversion_67',['queryVersion',['../classfirmata_1_1_firmata_marshaller.html#a488fbbd372c894ec78ebb99e0faf5167',1,'firmata::FirmataMarshaller']]]
];
